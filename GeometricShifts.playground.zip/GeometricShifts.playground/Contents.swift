
/* 
 * Game: Geometric Shifts
 * Author: Ellen Bianca Mota de Carvalho
 * Date: 25/03/2017
 * Version: 1.0
 */


import UIKit
import PlaygroundSupport
import SpriteKit

//: # GAME SHIFTS
//:
//: ## ABOUT
//:
//: Its a game where the goal is to arrive at the top of the screen, DO NOT TOUCH THE BARRIERS
//:
//: ## How to play
//:
//: Use the arrows to move Josh, the cube around the screen

//:
//: You can do it! Good luck!



let game = Game()













